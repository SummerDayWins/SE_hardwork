<template>
  <view class="container">
    <view class="header">
      <text class="page-title">{{ selectedProvince }}</text>
    </view>
    
    <view class="location-bar">
      <text class="province">{{ selectedProvince }}</text>
      <picker @change="onCityChange" :value="selectedCityIndex" :range="cityList" class="city-picker">
        <view class="city-select">
          <text>{{ selectedCity || '选择城市' }}</text>
          <text class="arrow">▼</text>
        </view>
      </picker>
    </view>

    <view class="spots-list">
      <view v-for="(spot, index) in filteredSpots" :key="index" class="spot-section">
        <view class="spot-header" @click="toggleSpot(index)">
          <text class="spot-name">{{ spot.name }}</text>
          <text class="expand-icon">{{ spot.isExpanded ? 'V' : '>' }}</text>
        </view>
        
        <view v-if="spot.isExpanded" class="spot-details">
          <!-- 景点类型与特色 -->
          <view class="detail-block">
            <view class="block-title">
              <view class="title-bar"></view>
              <text class="section-title">景点类型与特色</text>
            </view>
            <text class="block-content">{{ spot.typeAndFeatures }}</text>
            <image v-if="spot.mainImage" :src="spot.mainImage" mode="aspectFill" class="spot-image"/>
          </view>

          <!-- 建议游玩时间 -->
          <view class="detail-block">
            <view class="block-title">
              <view class="title-bar"></view>
              <text class="section-title">建议游玩时间</text>
            </view>
            <text class="block-content">{{ spot.suggestedTime }}</text>
          </view>

          <!-- 日均花费 -->
          <view class="detail-block">
            <view class="block-title">
              <view class="title-bar"></view>
              <text class="section-title">日均花费</text>
            </view>
            <view class="cost-grid">
              <view class="cost-item">
                <text class="cost-type">门票</text>
                <text class="cost-value">¥{{ spot.costs.ticket }}</text>
              </view>
              <view class="cost-item">
                <text class="cost-type">餐饮</text>
                <text class="cost-value">¥{{ spot.costs.food }}</text>
              </view>
              <view class="cost-item">
                <text class="cost-type">住宿</text>
                <text class="cost-value">¥{{ spot.costs.hotel }}</text>
              </view>
            </view>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<style>
.container {
  background-color: #f7f7f7;
  min-height: 100vh;
}

.header {
  padding: 30rpx 40rpx;
  background-color: #f7f7f7;
}

.page-title {
  font-size: 44rpx;
  font-weight: 700;
  color: #333;
  letter-spacing: 1px;
}

.location-bar {
  display: flex;
  align-items: center;
  padding: 24rpx 40rpx;
  background-color: #fff;
  box-shadow: 0 2rpx 6rpx rgba(0, 0, 0, 0.04);
}

.province {
  font-size: 30rpx;
  font-weight: 500;
  margin-right: 20rpx;
  color: #333;
}

.city-select {
  display: flex;
  align-items: center;
  font-size: 28rpx;
  color: #666;
  background-color: #f5f7fa;
  padding: 10rpx 20rpx;
  border-radius: 8rpx;
}

.arrow {
  margin-left: 10rpx;
  font-size: 24rpx;
  color: #999;
}

.spots-list {
  margin-top: 20rpx;
  padding: 0 20rpx;
}

.spot-section {
  background-color: #fff;
  margin-bottom: 20rpx;
  border-radius: 12rpx;
  overflow: hidden;
  box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.04);
}

.spot-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 32rpx 30rpx;
  position: relative;
}

.spot-name {
  font-size: 34rpx;
  font-weight: 600;
  color: #333;
}

.expand-icon {
  color: #999;
  font-size: 24rpx;
  font-weight: 500;
}

.spot-details {
  padding: 0 30rpx 30rpx;
}

.detail-block {
  margin-bottom: 40rpx;
}

.block-title {
  display: flex;
  align-items: center;
  margin-bottom: 20rpx;
}

.title-bar {
  width: 6rpx;
  height: 32rpx;
  background-color: #1890ff;
  margin-right: 12rpx;
  border-radius: 3rpx;
}

.section-title {
  font-size: 32rpx;
  font-weight: 600;
  color: #333;
}

.block-content {
  font-size: 28rpx;
  color: #666;
  line-height: 1.7;
  text-align: justify;
}

.spot-image {
  width: 100%;
  height: 340rpx;
  margin-top: 20rpx;
  border-radius: 12rpx;
}

.cost-grid {
  display: flex;
  justify-content: space-between;
  margin-top: 20rpx;
  background-color: #f8fafc;
  padding: 24rpx;
  border-radius: 12rpx;
}

.cost-item {
  text-align: center;
  flex: 1;
  position: relative;
}

.cost-item:not(:last-child)::after {
  content: '';
  position: absolute;
  right: 0;
  top: 50%;
  transform: translateY(-50%);
  height: 70%;
  width: 1px;
  background-color: #eee;
}

.cost-type {
  font-size: 28rpx;
  color: #666;
  margin-bottom: 12rpx;
  display: block;
}

.cost-value {
  font-size: 36rpx;
  color: #ff4d4f;
  font-weight: 600;
}
</style>

<script>
export default {
  data() {
    return {
      selectedProvince: '',
      selectedCity: '',
      selectedCityIndex: 0,
      cityList: ['不限城市'],
      spots: []
    }
  },
  computed: {
      filteredSpots() {
        if (!this.selectedCity || this.selectedCity === '不限城市') {
          return this.spots;
        }
        return this.spots.filter(spot => spot.city === this.selectedCity);
      }
    },
    onLoad() {
      // 从本地存储获取选择的省份
      this.selectedProvince = localStorage.getItem('selectedProvince');
      this.loadCityData();
      this.loadSpotData();
    },
    methods: {
      loadCityData() {
        // 根据选择的省份加载对应的城市列表
        const provinceCities = {
          '福建': ['不限城市', '福州', '厦门', '泉州', '漳州', '莆田', '三明', '南平', '龙岩', '宁德'],
          '浙江': ['不限城市', '杭州', '宁波', '温州', '绍兴', '湖州', '嘉兴', '金华', '衢州', '舟山', '台州', '丽水'],
          '江苏': ['不限城市', '南京', '苏州', '无锡', '常州', '南通', '扬州', '镇江', '徐州', '泰州', '盐城', '连云港', '宿迁'],
          '北京': ['不限城市', '东城区', '西城区', '朝阳区', '海淀区', '丰台区', '石景山区', '门头沟区', '房山区', '通州区', '顺义区', '昌平区', '大兴区', '怀柔区', '平谷区', '密云区', '延庆区'],
          '上海': ['不限城市', '黄浦区', '徐汇区', '长宁区', '静安区', '普陀区', '虹口区', '杨浦区', '闵行区', '宝山区', '嘉定区', '浦东新区', '金山区', '松江区', '青浦区', '奉贤区', '崇明区'],
          // 可以继续添加其他省份的城市
        };
  
        // 获取当前选择省份的城市列表
        this.cityList = provinceCities[this.selectedProvince] || ['不限城市'];
        
        // 重置选中的城市为默认值
        this.selectedCity = '不限城市';
        this.selectedCityIndex = 0;
      },
      loadSpotData() {
        // 这里可以根据选择的省份和城市加载对应的景点数据
        // 目前使用静态数据，后续可以改为从API获取
        console.log('加载景点数据:', this.selectedProvince, this.selectedCity);
      },
      onCityChange(e) {
        this.selectedCityIndex = e.detail.value;
        this.selectedCity = this.cityList[this.selectedCityIndex];
      },
      toggleSpot(index) {
        this.spots[index].isExpanded = !this.spots[index].isExpanded;
      }
    }
  };
  </script>